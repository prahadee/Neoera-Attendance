<?php
header('Content-Type: application/json');
echo json_encode([
    'message' => 'Users endpoint - will manage employees',
    'method' => $_SERVER['REQUEST_METHOD']
]);
?>