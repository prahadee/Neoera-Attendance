<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// Get the requested path
$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);

// Extract the API path
$api_path = str_replace('/attendance/api/', '', $path);
$api_path = str_replace('/api/', '', $api_path);
$api_path = trim($api_path, '/');

// If path comes from .htaccess
if (empty($api_path) && isset($_GET['path'])) {
    $api_path = $_GET['path'];
}

error_log("API Request: " . $api_path . " - Full URI: " . $request_uri);

// Route the request
switch ($api_path) {
    case 'health':
    case '':
        echo json_encode([
            'status' => 'OK', 
            'timestamp' => date('c'),
            'service' => 'Neoera Attendance System',
            'version' => '1.0',
            'api_path' => $api_path,
            'request_uri' => $request_uri
        ]);
        break;
        
    case 'test':
        echo json_encode(['message' => 'Test successful!', 'path' => $api_path]);
        break;
        
    default:
        http_response_code(404);
        echo json_encode([
            'message' => 'Endpoint not found',
            'requested_path' => $api_path,
            'full_uri' => $request_uri
        ]);
        break;
}
?>