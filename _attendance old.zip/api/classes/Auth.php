<?php
require_once 'config/database.php';

class Auth {
    private $conn;
    private $table = 'users';
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    public function register($employeeId, $name, $email, $password, $role, $department, $position) {
        try {
            // Check if user exists
            $query = "SELECT id FROM " . $this->table . " WHERE employee_id = ? OR email = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$employeeId, $email]);
            
            if ($stmt->rowCount() > 0) {
                return ['success' => false, 'message' => 'User already exists'];
            }
            
            // Hash password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert user
            $query = "INSERT INTO " . $this->table . " 
                     (employee_id, name, email, password, role, department, position) 
                     VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$employeeId, $name, $email, $hashedPassword, $role, $department, $position]);
            
            return [
                'success' => true,
                'message' => 'User created successfully',
                'user' => [
                    'id' => $this->conn->lastInsertId(),
                    'employeeId' => $employeeId,
                    'name' => $name,
                    'email' => $email
                ]
            ];
        } catch (Exception $e) {
            error_log("Registration error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Registration failed'];
        }
    }
    
    public function login($email, $password) {
        try {
            $query = "SELECT id, employee_id, name, email, password, role, department, 
                             permissions_limit, permissions_used, is_active 
                      FROM " . $this->table . " WHERE email = ? AND is_active = TRUE";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if (!$user || !password_verify($password, $user['password'])) {
                return ['success' => false, 'message' => 'Invalid credentials'];
            }
            
            // Generate JWT token
            $token = $this->generateJWT([
                'userId' => $user['id'],
                'employeeId' => $user['employee_id'],
                'email' => $user['email'],
                'role' => $user['role']
            ]);
            
            unset($user['password']);
            
            return [
                'success' => true,
                'token' => $token,
                'user' => $user
            ];
        } catch (Exception $e) {
            error_log("Login error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Login failed'];
        }
    }
    
    public function validateToken($token) {
        try {
            $parts = explode('.', $token);
            if (count($parts) != 3) return false;
            
            $payload = json_decode(base64_decode($parts[1]), true);
            if (!$payload || !isset($payload['exp']) || $payload['exp'] < time()) {
                return false;
            }
            
            // Verify signature
            $expected = base64_encode(hash_hmac('sha256', $parts[0] . "." . $parts[1], JWT_SECRET, true));
            if ($parts[2] !== str_replace(['+', '/', '='], ['-', '_', ''], $expected)) {
                return false;
            }
            
            return $payload;
        } catch (Exception $e) {
            error_log("Token validation error: " . $e->getMessage());
            return false;
        }
    }
    
    private function generateJWT($payload) {
        $header = ['alg' => 'HS256', 'typ' => 'JWT'];
        $payload['exp'] = time() + (24 * 60 * 60); // 24 hours
        
        $header_encoded = $this->base64UrlEncode(json_encode($header));
        $payload_encoded = $this->base64UrlEncode(json_encode($payload));
        
        $signature = hash_hmac('sha256', $header_encoded . "." . $payload_encoded, JWT_SECRET, true);
        $signature_encoded = $this->base64UrlEncode($signature);
        
        return $header_encoded . "." . $payload_encoded . "." . $signature_encoded;
    }
    
    private function base64UrlEncode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
}
?>