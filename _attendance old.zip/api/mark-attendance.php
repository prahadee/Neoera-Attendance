<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

require_once 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employeeId = $_POST['employeeId'] ?? '';
    $qrCode = $_POST['qrCode'] ?? '';
    $type = $_POST['type'] ?? '';
    $latitude = $_POST['latitude'] ?? '';
    $longitude = $_POST['longitude'] ?? '';
    
    // Validate required fields
    if (empty($employeeId) || empty($qrCode) || empty($type) || empty($latitude) || empty($longitude)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        exit;
    }
    
    $database = new Database();
    $conn = $database->getConnection();
    
    if (!$conn) {
        echo json_encode(['success' => false, 'message' => 'Database connection failed']);
        exit;
    }
    
    try {
        // Clean expired QR codes first
        $cleanQuery = "DELETE FROM qr_codes WHERE expires_at <= NOW()";
        $conn->exec($cleanQuery);
        
        // Verify QR code from database
        $qrQuery = "SELECT type, expires_at FROM qr_codes WHERE code = ?";
        $qrStmt = $conn->prepare($qrQuery);
        $qrStmt->execute([$qrCode]);
        $qrData = $qrStmt->fetch();
        
        if (!$qrData) {
            echo json_encode(['success' => false, 'message' => 'Invalid QR code. Please generate a new one.']);
            exit;
        }
        
        // Check if QR code is expired
        if (strtotime($qrData['expires_at']) < time()) {
            echo json_encode(['success' => false, 'message' => 'QR code has expired. Please generate a new one.']);
            exit;
        }
        
        // Check if QR code type matches
        if ($qrData['type'] !== $type) {
            echo json_encode(['success' => false, 'message' => 'This QR code is for ' . $qrData['type'] . ', but you are trying to ' . $type]);
            exit;
        }
        
        // Verify employee exists
        $empQuery = "SELECT id, permissions_limit, permissions_used FROM users WHERE employee_id = ? AND is_active = 1";
        $empStmt = $conn->prepare($empQuery);
        $empStmt->execute([$employeeId]);
        $employee = $empStmt->fetch();
        
        if (!$employee) {
            echo json_encode(['success' => false, 'message' => 'Employee not found or inactive']);
            exit;
        }
        
        // Handle selfie upload
        $selfiePath = null;
        if (isset($_FILES['selfie']) && $_FILES['selfie']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = '../uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $fileName = uniqid() . '_' . time() . '.jpg';
            $filePath = $uploadDir . $fileName;
            
            if (move_uploaded_file($_FILES['selfie']['tmp_name'], $filePath)) {
                $selfiePath = $fileName;
            }
        }
        
        $currentTime = date('Y-m-d H:i:s');
        $today = date('Y-m-d');
        
        // Get or create today's attendance record
        $attendanceQuery = "SELECT id FROM attendance WHERE employee_id = ? AND date = ?";
        $attendanceStmt = $conn->prepare($attendanceQuery);
        $attendanceStmt->execute([$employeeId, $today]);
        $attendanceRecord = $attendanceStmt->fetch();
        
        if ($attendanceRecord) {
            $attendanceId = $attendanceRecord['id'];
        } else {
            // Create new attendance record
            $insertQuery = "INSERT INTO attendance (employee_id, date, status) VALUES (?, ?, 'present')";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->execute([$employeeId, $today]);
            $attendanceId = $conn->lastInsertId();
        }
        
        // Update based on attendance type
        switch ($type) {
            case 'check-in':
                $checkInTime = strtotime($currentTime);
                $lateThreshold = strtotime(date('Y-m-d 09:35:00'));
                $isLate = $checkInTime > $lateThreshold;
                $lateMinutes = $isLate ? floor(($checkInTime - $lateThreshold) / 60) : 0;
                
                $updateQuery = "UPDATE attendance SET 
                               check_in_time = ?, check_in_lat = ?, check_in_lng = ?, 
                               check_in_selfie = ?, check_in_late = ?, late_minutes = ? 
                               WHERE id = ?";
                $updateStmt = $conn->prepare($updateQuery);
                $updateStmt->execute([$currentTime, $latitude, $longitude, $selfiePath, $isLate, $lateMinutes, $attendanceId]);
                
                // Handle late arrival permissions
                if ($isLate) {
                    handleLateArrival($conn, $employee['id'], $attendanceId);
                }
                break;
                
            case 'lunch-start':
                $updateQuery = "UPDATE attendance SET 
                               lunch_start_time = ?, lunch_lat = ?, lunch_lng = ?, lunch_selfie = ? 
                               WHERE id = ?";
                $updateStmt = $conn->prepare($updateQuery);
                $updateStmt->execute([$currentTime, $latitude, $longitude, $selfiePath, $attendanceId]);
                break;
                
            case 'lunch-end':
                // Get lunch start time to calculate duration
                $lunchQuery = "SELECT lunch_start_time FROM attendance WHERE id = ?";
                $lunchStmt = $conn->prepare($lunchQuery);
                $lunchStmt->execute([$attendanceId]);
                $lunchData = $lunchStmt->fetch();
                
                if ($lunchData && $lunchData['lunch_start_time']) {
                    $lunchDuration = floor((strtotime($currentTime) - strtotime($lunchData['lunch_start_time'])) / 60);
                    
                    $updateQuery = "UPDATE attendance SET 
                                   lunch_end_time = ?, lunch_duration = ?, lunch_lat = ?, lunch_lng = ?, lunch_selfie = ? 
                                   WHERE id = ?";
                    $updateStmt = $conn->prepare($updateQuery);
                    $updateStmt->execute([$currentTime, $lunchDuration, $latitude, $longitude, $selfiePath, $attendanceId]);
                    
                    // Check if lunch exceeded 45 minutes
                    if ($lunchDuration > 45) {
                        $statusQuery = "UPDATE attendance SET status = 'half-day' WHERE id = ? AND status = 'present'";
                        $statusStmt = $conn->prepare($statusQuery);
                        $statusStmt->execute([$attendanceId]);
                    }
                } else {
                    echo json_encode(['success' => false, 'message' => 'Lunch not started yet. Please start lunch first.']);
                    exit;
                }
                break;
                
            case 'check-out':
                $updateQuery = "UPDATE attendance SET 
                               check_out_time = ?, check_out_lat = ?, check_out_lng = ?, check_out_selfie = ? 
                               WHERE id = ?";
                $updateStmt = $conn->prepare($updateQuery);
                $updateStmt->execute([$currentTime, $latitude, $longitude, $selfiePath, $attendanceId]);
                break;
        }
        
        // Delete used QR code
        $deleteQrQuery = "DELETE FROM qr_codes WHERE code = ?";
        $deleteQrStmt = $conn->prepare($deleteQrQuery);
        $deleteQrStmt->execute([$qrCode]);
        
        echo json_encode([
            'success' => true,
            'message' => ucfirst(str_replace('-', ' ', $type)) . ' recorded successfully!',
            'data' => [
                'employee_id' => $employeeId,
                'type' => $type,
                'timestamp' => $currentTime,
                'location' => ['lat' => $latitude, 'lng' => $longitude],
                'selfie' => $selfiePath ? 'Uploaded' : 'Not uploaded'
            ]
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['message' => 'Please use POST method']);
}

function handleLateArrival($conn, $userId, $attendanceId) {
    // Reset permissions if new month
    $resetQuery = "UPDATE users SET permissions_used = 0, permission_reset_date = NOW() 
                   WHERE id = ? AND MONTH(permission_reset_date) != MONTH(NOW())";
    $resetStmt = $conn->prepare($resetQuery);
    $resetStmt->execute([$userId]);
    
    // Check permissions
    $permQuery = "SELECT permissions_limit, permissions_used FROM users WHERE id = ?";
    $permStmt = $conn->prepare($permQuery);
    $permStmt->execute([$userId]);
    $permissions = $permStmt->fetch();
    
    if ($permissions['permissions_used'] < $permissions['permissions_limit']) {
        // Use one permission
        $usePermQuery = "UPDATE users SET permissions_used = permissions_used + 1 WHERE id = ?";
        $usePermStmt = $conn->prepare($usePermQuery);
        $usePermStmt->execute([$userId]);
    } else {
        // Convert to half-day
        $halfDayQuery = "UPDATE attendance SET status = 'half-day' WHERE id = ?";
        $halfDayStmt = $conn->prepare($halfDayQuery);
        $halfDayStmt->execute([$attendanceId]);
    }
}
?>