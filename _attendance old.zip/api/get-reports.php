<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

require_once 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $startDate = $_GET['startDate'] ?? date('Y-m-01');
    $endDate = $_GET['endDate'] ?? date('Y-m-d');
    $employeeId = $_GET['employeeId'] ?? '';
    $department = $_GET['department'] ?? '';
    
    $database = new Database();
    $conn = $database->getConnection();
    
    if (!$conn) {
        echo json_encode(['success' => false, 'message' => 'Database connection failed']);
        exit;
    }
    
    try {
        // Build query for attendance data
        $query = "SELECT a.*, u.name, u.department, u.position 
                 FROM attendance a 
                 JOIN users u ON a.employee_id = u.employee_id 
                 WHERE a.date BETWEEN ? AND ?";
        $params = [$startDate, $endDate];
        
        if (!empty($employeeId)) {
            $query .= " AND a.employee_id = ?";
            $params[] = $employeeId;
        }
        
        if (!empty($department)) {
            $query .= " AND u.department = ?";
            $params[] = $department;
        }
        
        $query .= " ORDER BY a.date DESC, a.check_in_time DESC";
        
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        $attendance = $stmt->fetchAll();
        
        // Get statistics
        $statsQuery = "SELECT 
            COUNT(DISTINCT u.id) as total_employees,
            COUNT(DISTINCT a.employee_id) as employees_present,
            AVG(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) * 100 as attendance_rate,
            SUM(CASE WHEN a.check_in_late = 1 THEN 1 ELSE 0 END) as total_late
            FROM users u 
            LEFT JOIN attendance a ON u.employee_id = a.employee_id AND a.date BETWEEN ? AND ?
            WHERE u.is_active = 1";
        
        $statsStmt = $conn->prepare($statsQuery);
        $statsStmt->execute([$startDate, $endDate]);
        $stats = $statsStmt->fetch();
        
        echo json_encode([
            'success' => true,
            'attendance' => $attendance,
            'stats' => $stats,
            'total' => count($attendance)
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['message' => 'Please use GET method']);
}
?>