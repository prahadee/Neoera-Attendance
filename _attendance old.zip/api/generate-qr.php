<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

require_once 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $type = $input['type'] ?? '';
    
    $validTypes = ['check-in', 'lunch-start', 'lunch-end', 'check-out'];
    if (!in_array($type, $validTypes)) {
        echo json_encode(['success' => false, 'message' => 'Invalid QR type']);
        exit;
    }
    
    $database = new Database();
    $conn = $database->getConnection();
    
    if ($conn) {
        try {
            // Generate unique QR code
            $code = bin2hex(random_bytes(16));
            $expiresAt = date('Y-m-d H:i:s', time() + 300); // 5 minutes
            
            // Insert into database
            $query = "INSERT INTO qr_codes (type, code, expires_at) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->execute([$type, $code, $expiresAt]);
            
            echo json_encode([
                'success' => true,
                'qrCode' => $code,
                'expiresAt' => $expiresAt,
                'message' => 'QR code generated successfully'
            ]);
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
    } else {
        // Fallback without database
        $code = 'QR_' . strtoupper($type) . '_' . time() . '_' . bin2hex(random_bytes(4));
        $expiresAt = date('Y-m-d H:i:s', time() + 300);
        
        echo json_encode([
            'success' => true,
            'qrCode' => $code,
            'expiresAt' => $expiresAt,
            'message' => 'QR code generated (offline mode)'
        ]);
    }
} else {
    echo json_encode(['message' => 'Please use POST method']);
}
?>