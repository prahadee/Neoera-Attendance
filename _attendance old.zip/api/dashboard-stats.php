<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

require_once 'config/database.php';

// Check authentication
$headers = apache_request_headers();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit;
}

$database = new Database();
$conn = $database->getConnection();

if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

try {
    $today = date('Y-m-d');
    
    // Get real statistics from database
    $statsQuery = "SELECT 
        (SELECT COUNT(*) FROM users WHERE is_active = 1) as total_employees,
        (SELECT COUNT(DISTINCT employee_id) FROM attendance WHERE date = ?) as present_today,
        (SELECT COUNT(*) FROM attendance WHERE date = ? AND check_in_late = 1) as late_today,
        (SELECT COUNT(DISTINCT u.employee_id) 
         FROM users u 
         LEFT JOIN attendance a ON u.employee_id = a.employee_id AND a.date = ? 
         WHERE u.is_active = 1 AND a.employee_id IS NULL) as absent_today";
    
    $statsStmt = $conn->prepare($statsQuery);
    $statsStmt->execute([$today, $today, $today]);
    $stats = $statsStmt->fetch();
    
    // Calculate attendance rate
    $attendanceRate = $stats['total_employees'] > 0 ? 
        round(($stats['present_today'] / $stats['total_employees']) * 100, 1) : 0;
    
    echo json_encode([
        'success' => true,
        'stats' => [
            'totalEmployees' => $stats['total_employees'],
            'presentToday' => $stats['present_today'],
            'lateToday' => $stats['late_today'],
            'absentToday' => $stats['absent_today'],
            'attendanceRate' => $attendanceRate
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>