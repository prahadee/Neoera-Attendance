<?php
header('Content-Type: application/json');
echo json_encode([
    'status' => 'OK', 
    'timestamp' => date('c'),
    'service' => 'Neoera Attendance System',
    'version' => '1.0',
    'message' => 'Health check successful!'
]);
?>