<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

require_once 'config/database.php';

// Check authentication
$headers = apache_request_headers();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $required = ['employee_id', 'name', 'email', 'password', 'department', 'position', 'role'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            echo json_encode(['success' => false, 'message' => $field . ' is required']);
            exit;
        }
    }
    
    // Validate email format
    if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        exit;
    }
    
    // Validate password length
    if (strlen($input['password']) < 6) {
        echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters long']);
        exit;
    }
    
    $database = new Database();
    $conn = $database->getConnection();
    
    if (!$conn) {
        echo json_encode(['success' => false, 'message' => 'Database connection failed']);
        exit;
    }
    
    try {
        // Check if employee ID already exists
        $checkIdQuery = "SELECT id FROM users WHERE employee_id = ?";
        $checkIdStmt = $conn->prepare($checkIdQuery);
        $checkIdStmt->execute([$input['employee_id']]);
        
        if ($checkIdStmt->rowCount() > 0) {
            echo json_encode(['success' => false, 'message' => 'Employee ID already exists']);
            exit;
        }
        
        // Check if email already exists
        $checkEmailQuery = "SELECT id FROM users WHERE email = ?";
        $checkEmailStmt = $conn->prepare($checkEmailQuery);
        $checkEmailStmt->execute([$input['email']]);
        
        if ($checkEmailStmt->rowCount() > 0) {
            echo json_encode(['success' => false, 'message' => 'Email already exists']);
            exit;
        }
        
        // Hash password
        $hashedPassword = password_hash($input['password'], PASSWORD_DEFAULT);
        
        // Insert employee
        $query = "INSERT INTO users (employee_id, name, email, password, role, department, position, permissions_limit) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            $input['employee_id'],
            $input['name'],
            $input['email'],
            $hashedPassword,
            $input['role'],
            $input['department'],
            $input['position'],
            $input['role'] === 'admin' ? 5 : 2 // Admins get more permissions
        ]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Employee added successfully!',
            'employee_id' => $input['employee_id']
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['message' => 'Please use POST method']);
}
?>