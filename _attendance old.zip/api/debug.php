<?php
header('Content-Type: application/json');

echo json_encode([
    'message' => 'Debug API is working!',
    'server_info' => [
        'request_uri' => $_SERVER['REQUEST_URI'],
        'query_string' => $_SERVER['QUERY_STRING'],
        'path_info' => $_SERVER['PATH_INFO'] ?? 'Not set',
        'script_name' => $_SERVER['SCRIPT_NAME']
    ],
    'get_params' => $_GET,
    'post_data' => $_POST
]);
?>