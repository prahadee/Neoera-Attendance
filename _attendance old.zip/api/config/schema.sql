-- Run this in your Hostinger MySQL database

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS users, attendance, qr_codes;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('employee', 'admin', 'super-admin') DEFAULT 'employee',
    department VARCHAR(100),
    position VARCHAR(100),
    permissions_limit INT DEFAULT 2,
    permissions_used INT DEFAULT 0,
    permission_reset_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_employee_id (employee_id),
    INDEX idx_email (email)
);

CREATE TABLE attendance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    
    -- Check-in data
    check_in_time DATETIME,
    check_in_lat DECIMAL(10, 8),
    check_in_lng DECIMAL(11, 8),
    check_in_selfie VARCHAR(255),
    check_in_late BOOLEAN DEFAULT FALSE,
    
    -- Lunch break data
    lunch_start_time DATETIME,
    lunch_end_time DATETIME,
    lunch_duration INT,
    lunch_lat DECIMAL(10, 8),
    lunch_lng DECIMAL(11, 8),
    lunch_selfie VARCHAR(255),
    
    -- Check-out data
    check_out_time DATETIME,
    check_out_lat DECIMAL(10, 8),
    check_out_lng DECIMAL(11, 8),
    check_out_selfie VARCHAR(255),
    
    status ENUM('present', 'half-day', 'absent') DEFAULT 'present',
    late_minutes INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE KEY unique_employee_date (employee_id, date),
    INDEX idx_employee_date (employee_id, date),
    INDEX idx_date (date),
    FOREIGN KEY (employee_id) REFERENCES users(employee_id) ON DELETE CASCADE
);

CREATE TABLE qr_codes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    type ENUM('check-in', 'lunch-start', 'lunch-end', 'check-out') NOT NULL,
    code VARCHAR(100) UNIQUE NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_code (code),
    INDEX idx_expires (expires_at)
);

-- Create super admin with YOUR credentials
INSERT INTO users (employee_id, name, email, password, role, department, position) 
VALUES (
    'NEOERA001', 
    'Rajesh Neoera', 
    'contact@neoerainfotech.com', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',  -- Rajesh@neo1997
    'super-admin', 
    'Administration', 
    'Super Admin'
);

SET FOREIGN_KEY_CHECKS=1;