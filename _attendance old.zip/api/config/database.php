<?php
class Database {
    private $host = "localhost";
    private $db_name = "u957189082_attendance";
    private $username = "u957189082_admin";
    private $password = "Rajesh@neo1997";
    public $conn;
    
    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4",
                $this->username,
                $this->password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]
            );
            return $this->conn;
        } catch(PDOException $exception) {
            return false;
        }
    }
}
?>