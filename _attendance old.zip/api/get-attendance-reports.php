<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../config/database.php';

// Get the request parameters
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$employee_id = $_GET['employee_id'] ?? '';
$department = $_GET['department'] ?? '';

try {
    // Build the query
    $query = "
        SELECT 
            a.*,
            u.name as employee_name,
            u.department
        FROM attendance a
        JOIN users u ON a.employee_id = u.employee_id
        WHERE a.date BETWEEN ? AND ?
    ";
    
    $params = [$start_date, $end_date];
    
    if (!empty($employee_id)) {
        $query .= " AND a.employee_id = ?";
        $params[] = $employee_id;
    }
    
    if (!empty($department)) {
        $query .= " AND u.department = ?";
        $params[] = $department;
    }
    
    $query .= " ORDER BY a.date DESC, a.check_in_time DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get stats
    $stats_query = "
        SELECT 
            COUNT(DISTINCT u.id) as totalEmployees,
            COUNT(DISTINCT CASE WHEN a.date = CURDATE() THEN a.employee_id END) as presentToday,
            COUNT(CASE WHEN a.check_in_late = 1 AND a.date = CURDATE() THEN 1 END) as totalLate,
            COUNT(DISTINCT a.date) as workingDays
        FROM users u
        LEFT JOIN attendance a ON u.employee_id = a.employee_id AND a.date BETWEEN ? AND ?
        WHERE u.is_active = 1
    ";
    
    $stats_stmt = $pdo->prepare($stats_query);
    $stats_stmt->execute([$start_date, $end_date]);
    $stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get summary
    $summary_query = "
        SELECT 
            COUNT(*) as totalRecords,
            COUNT(CASE WHEN a.status = 'present' THEN 1 END) as presentCount,
            COUNT(CASE WHEN a.check_in_late = 1 THEN 1 END) as lateCount,
            GROUP_CONCAT(DISTINCT u.department) as departmentBreakdown
        FROM attendance a
        JOIN users u ON a.employee_id = u.employee_id
        WHERE a.date BETWEEN ? AND ?
    ";
    
    $summary_params = [$start_date, $end_date];
    
    if (!empty($employee_id)) {
        $summary_query .= " AND a.employee_id = ?";
        $summary_params[] = $employee_id;
    }
    
    if (!empty($department)) {
        $summary_query .= " AND u.department = ?";
        $summary_params[] = $department;
    }
    
    $summary_stmt = $pdo->prepare($summary_query);
    $summary_stmt->execute($summary_params);
    $summary = $summary_stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'attendance' => $attendance,
        'stats' => $stats,
        'summary' => $summary
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>