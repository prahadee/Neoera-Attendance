<?php
header('Content-Type: text/html; charset=utf-8');
echo "<h3>QR Scan Test</h3>";

// Test data
$testQR = "QR_CHECK-IN_" . time() . "_test123";
$testType = "check-in";

require_once 'api/config/database.php';
$database = new Database();
$conn = $database->getConnection();

if ($conn) {
    // Insert test QR
    $conn->exec("DELETE FROM qr_codes WHERE code = '$testQR'");
    $stmt = $conn->prepare("INSERT INTO qr_codes (type, code, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 5 MINUTE))");
    $stmt->execute([$testType, $testQR]);
    
    echo "<p>Test QR Created: <strong>$testQR</strong></p>";
    echo "<p>Type: $testType</p>";
    echo "<p>Use this in the scanner to test!</p>";
} else {
    echo "<p>Database connection failed</p>";
}
?>