<?php
echo "TEST: PHP is working!";
?>